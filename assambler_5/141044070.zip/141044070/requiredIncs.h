//
// Created by ridvan on 14.11.2016.
//
#include <iostream>
#include "computer.h"
#include "CPUProgram.h"
#include "myCpu.h"
#ifndef INC_141044070_REQUIREDINCS_H
#define INC_141044070_REQUIREDINCS_H

    //pdf deki verilen test kodlarını dener
    void Test1Function(const char* fileName,int option);
    //siralama kodunu dener hw 4 deki kod ancak operatorler kullanıldı
    void Test2Function(const char *fileNem,int option);
//klavyeden girilen iki sayinin carpimi
    void test3Function(const char*fileName,int option);
#endif //INC_141044070_REQUİREDINCS_H
